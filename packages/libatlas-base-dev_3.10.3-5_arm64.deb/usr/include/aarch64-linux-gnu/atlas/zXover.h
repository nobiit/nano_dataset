#ifndef ZXOVER_H
#define ZXOVER_H

#define ATL_3NB 216
#define NN_MNK_M 7200
#define NN_MNK_N 103968
#define NN_MNK_MN 51840
#define NN_MNK_K 16200
#define NN_MNK_GE 54872
#define NT_MNK_M 7200
#define NT_MNK_N 7200
#define NT_MNK_MN 51840
#define NT_MNK_K 16200
#define NT_MNK_GE 3375
#define TN_MNK_M 352800
#define TN_MNK_N 352800
#define TN_MNK_MN 51840
#define TN_MNK_K 267912
#define TN_MNK_GE 343000
#define TT_MNK_M 202248
#define TT_MNK_N 7200
#define TT_MNK_MN 51840
#define TT_MNK_K 202248
#define TT_MNK_GE 148877
#define C2R_K 278

#endif
