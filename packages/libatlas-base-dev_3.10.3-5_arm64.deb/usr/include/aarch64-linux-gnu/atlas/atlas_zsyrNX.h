#ifndef ATLAS_ZSYR_H
   #define ATLAS_ZSYR_H
   #define ATL_S1NX 368
#endif
