#ifndef SXOVER_H
#define SXOVER_H

#define ATL_3NB 216
#define NN_MNK_M 7200
#define NN_MNK_N 64800
#define NN_MNK_MN 51840
#define NN_MNK_K 7200
#define NN_MNK_GE 27000
#define NT_MNK_M 7200
#define NT_MNK_N 7200
#define NT_MNK_MN 51840
#define NT_MNK_K 7200
#define NT_MNK_GE 3375
#define TN_MNK_M 16200
#define TN_MNK_N 64800
#define TN_MNK_MN 51840
#define TN_MNK_K 16200
#define TN_MNK_GE 54872
#define TT_MNK_M 16200
#define TT_MNK_N 7200
#define TT_MNK_MN 51840
#define TT_MNK_K 7200
#define TT_MNK_GE 3375

#endif
