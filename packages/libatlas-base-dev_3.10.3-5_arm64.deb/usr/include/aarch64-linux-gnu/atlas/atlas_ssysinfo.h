#ifndef ATL_SSYSINFO_H
   #define ATL_SSYSINFO_H

#define ATL_MULADD
#define ATL_L1elts 32768
#define ATL_fplat  7
#define ATL_lbnreg 32
#define ATL_mmnreg 32
#define ATL_nkflop 2511281

#endif
