#ifndef ATL_ZSYSINFO_H
   #define ATL_ZSYSINFO_H

#define ATL_MULADD
#define ATL_L1elts 16384
#define ATL_fplat  7
#define ATL_lbnreg 32
#define ATL_mmnreg 32
#define ATL_nkflop 2516287

#endif
