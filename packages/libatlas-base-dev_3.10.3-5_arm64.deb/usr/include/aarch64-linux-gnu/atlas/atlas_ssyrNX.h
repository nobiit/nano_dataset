#ifndef ATLAS_SSYR_H
   #define ATLAS_SSYR_H
   #define ATL_S1NX 96
#endif
