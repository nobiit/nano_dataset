#ifndef DXOVER_H
#define DXOVER_H

#define ATL_3NB 216
#define NN_MNK_M 7200
#define NN_MNK_N 352800
#define NN_MNK_MN 51840
#define NN_MNK_K 16200
#define NN_MNK_GE 13824
#define NT_MNK_M 7200
#define NT_MNK_N 7200
#define NT_MNK_MN 51840
#define NT_MNK_K 7200
#define NT_MNK_GE 3375
#define TN_MNK_M 352800
#define TN_MNK_N 352800
#define TN_MNK_MN 51840
#define TN_MNK_K 352800
#define TN_MNK_GE 343000
#define TT_MNK_M 64800
#define TT_MNK_N 7200
#define TT_MNK_MN 51840
#define TT_MNK_K 16200
#define TT_MNK_GE 3375

#endif
